"use strict";
/* ---------- tiny helpers ---------- */
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const money = (n, c = "USD") => new Intl.NumberFormat(undefined, { style: "currency", currency: c }).format(+n || 0);
const iso = (d) => d.toISOString().slice(0, 10);
const LABEL = { awaiting_payment: "Awaiting payment", pending: "Finding driver", assigned: "Driver offered", accepted: "Driver heading to pickup", picked_up: "Out for delivery", delivered: "Delivered", failed: "Failed", cancelled: "Cancelled" };
const pill = (s) => `<span class="pill s-${esc(s)}">${esc(LABEL[s] || s)}</span>`;
const toast = (m, bad) => { const t = Object.assign(document.createElement("div"), { className: "toast" + (bad ? " bad" : ""), textContent: m }); $("#toasts").append(t); setTimeout(() => t.remove(), 4000); };

const S = { token: localStorage.token || "", role: localStorage.role || "", name: localStorage.name || "", timers: [] };
async function api(path, { method = "GET", json, form } = {}) {
  const r = await fetch("/api" + path, { method, headers: { ...(S.token && { Authorization: "Bearer " + S.token }), ...(json && { "Content-Type": "application/json" }) }, body: json ? JSON.stringify(json) : form });
  if (r.status === 204) return null;
  const d = await r.json().catch(() => ({}));
  if (r.status === 401 && S.token) { logout(); }
  if (!r.ok) throw Object.assign(new Error(d.error || "Request failed"), { fields: d.fields || {}, status: r.status });
  return d;
}
const poll = (fn, ms) => { fn(); S.timers.push(setInterval(() => document.hidden || fn(), ms)); };
const clearTimers = () => { S.timers.forEach(clearInterval); S.timers = []; };
function logout() { localStorage.clear(); S.token = ""; clearTimers(); route(); }

/* ---------- shell ---------- */
const NAV = {
  merchant: [["new", "➕", "New order"], ["orders", "📦", "Orders"]],
  admin: [["dispatch", "🧭", "Dispatch"], ["reports", "📈", "Reports"]],
  driver: [["jobs", "🛵", "My jobs"]],
};
function shell(view, title, sub, body) {
  $("#root").innerHTML = `<div class="app"><aside class="side"><div class="logo"><i>⚡</i>Courier</div>
    <nav class="nav" aria-label="Main">${NAV[S.role].map(([k, ic, t]) => `<a href="#${k}" class="${view === k ? "on" : ""}" ${view === k ? 'aria-current="page"' : ""}><span aria-hidden="true">${ic}</span>${t}</a>`).join("")}</nav>
    <div class="who"><b>${esc(S.name)}</b><br><small>${esc(S.role)}</small><br><a href="#" id="out" class="muted">Sign out</a></div></aside>
    <main><div class="head"><div><h1>${title}</h1><small>${sub}</small></div><div id="actions"></div></div>${body}</main></div>`;
  $("#out").onclick = (e) => { e.preventDefault(); logout(); };
}

/* ---------- login ---------- */
function loginView() {
  $("#root").innerHTML = `<div class="login"><form class="card" id="f" novalidate><div class="logo" style="padding:0"><i>⚡</i>Courier</div><div><h1>Welcome back</h1><small>Sign in to manage deliveries</small></div>
    <label>Email<input name="email" type="email" autocomplete="username" required></label><label>Password<input name="password" type="password" autocomplete="current-password" required></label>
    <div class="err" id="e" role="alert"></div><button class="btn block">Sign in</button></form></div>`;
  $("#f").onsubmit = async (e) => {
    e.preventDefault(); const f = new FormData(e.target), b = $(".btn", e.target); b.disabled = true;
    try { const d = await api("/auth/login", { method: "POST", json: Object.fromEntries(f) }); Object.assign(localStorage, { token: d.access_token, role: d.role, name: d.name }); Object.assign(S, { token: d.access_token, role: d.role, name: d.name }); location.hash = ""; route(); }
    catch (x) { $("#e").textContent = x.message; b.disabled = false; }
  };
}

/* ---------- merchant: new order ---------- */
function parsePin(v) { const m = /^\s*(-?\d{1,2}(?:\.\d+)?)\s*[, ]\s*(-?\d{1,3}(?:\.\d+)?)\s*$/.exec(v || ""); return m && Math.abs(m[1]) <= 90 && Math.abs(m[2]) <= 180 ? { lat: +m[1], lng: +m[2] } : null; }
function newOrderView() {
  shell("new", "New delivery", "Fill in the details — the fee updates as you type", `
  <div class="grid2"><form class="card stack" id="f" novalidate>
    <h2>Pickup</h2><div class="cols"><label>Pickup address <span class="opt">(optional — uses your saved address)</span><input name="pickup_address"><span class="err" data-e="pickup_address"></span></label>
    <label>Pickup pin <span class="opt">(lat, lng)</span><input name="pickup_pin" placeholder="36.1911, 44.0092"></label></div>
    <h2>Customer</h2><div class="cols"><label>Full name<input name="customer_name" autocomplete="off"><span class="err" data-e="customer_name"></span></label>
    <label>Phone<input name="customer_phone" inputmode="tel" placeholder="+9647501234567"><span class="err" data-e="customer_phone"></span></label></div>
    <div class="cols"><label>Dropoff address<input name="dropoff_address"><span class="err" data-e="dropoff_address"></span></label>
    <label>Dropoff pin <span class="opt">(right-click in Google Maps → copy)</span><input name="dropoff_pin" placeholder="36.2050, 44.0210"><span class="err" data-e="dropoff_lat"></span></label></div>
    <label>Notes for the driver <span class="opt">(optional)</span><textarea name="notes" rows="2" maxlength="500"></textarea></label>
    <h2>Parcel &amp; schedule</h2><div class="cols"><label>Weight (kg)<input name="weight_kg" type="number" step="0.1" min="0.1" max="50" value="1"><span class="err" data-e="weight_kg"></span></label>
    <label>Delivery date<input name="delivery_date" type="date" min="${iso(new Date())}" value="${iso(new Date())}"><span class="err" data-e="delivery_date"></span></label></div>
    <div><div class="choices" id="slots" role="radiogroup" aria-label="Time slot"></div><span class="err" data-e="time_slot_id"></span></div>
    <h2>Payment</h2><div class="choices"><button type="button" class="choice on" data-pm="cod"><b>Cash on Delivery</b><small>Driver collects cash from the customer</small></button>
    <button type="button" class="choice" data-pm="epayment"><b>E-Payment</b><small>Goods prepaid · delivery fee paid online</small></button></div>
    <label id="codw">Amount to collect<input name="cod_amount" type="number" step="0.01" min="0"><span class="err" data-e="cod_amount"></span></label></form>
    <aside class="card sticky fee" id="fee"><h2>Delivery fee</h2><div class="empty">Complete the form to see your price</div></aside></div>`);
  let pm = "cod", slot = null, lastKey = "";
  const f = $("#f");
  const val = () => { const p = parsePin(f.dropoff_pin.value), pp = parsePin(f.pickup_pin.value); const o = {
    customer_name: f.customer_name.value, customer_phone: f.customer_phone.value, dropoff_address: f.dropoff_address.value, notes: f.notes.value || undefined,
    weight_kg: +f.weight_kg.value, delivery_date: f.delivery_date.value, time_slot_id: slot, payment_method: pm, cod_amount: pm === "cod" ? +f.cod_amount.value || 0 : 0 };
    if (p) { o.dropoff_lat = p.lat; o.dropoff_lng = p.lng; } if (f.pickup_address.value.trim()) { o.pickup_address = f.pickup_address.value.trim(); if (pp) { o.pickup_lat = pp.lat; o.pickup_lng = pp.lng; } } return o; };
  const clientErr = (o) => { const e = {}; if ((o.customer_name || "").trim().length < 2) e.customer_name = "Enter the customer's name";
    if (!/^\+?[0-9]{8,15}$/.test((o.customer_phone || "").replace(/[\s-]/g, ""))) e.customer_phone = "Use international format, e.g. +9647501234567";
    if ((o.dropoff_address || "").trim().length < 5) e.dropoff_address = "Address is too short"; if (o.dropoff_lat == null) e.dropoff_lat = "Paste the pin as “lat, lng”";
    if (!o.time_slot_id) e.time_slot_id = "Choose a time slot"; if (!(o.weight_kg > 0 && o.weight_kg <= 50)) e.weight_kg = "0.1–50 kg"; if (o.payment_method === "cod" && !(o.cod_amount > 0)) e.cod_amount = "Enter the amount to collect"; return e; };
  const showErr = (e, only) => $$("[data-e]", f).forEach((n) => { const m = e[n.dataset.e] || ""; n.textContent = only && !only.has(n.dataset.e) ? n.textContent : m; n.previousElementSibling?.classList?.toggle("bad", !!m); });
  const touched = new Set();
  async function refresh() {
    const o = val(), e = clientErr(o); showErr(e, touched);
    if (Object.keys(e).length) { $("#fee").innerHTML = `<h2>Delivery fee</h2><div class="empty">Complete the form to see your price</div>`; $("#go")?.remove(); return; }
    const key = JSON.stringify(o); if (key === lastKey) return; lastKey = key;
    $("#fee").innerHTML = `<h2>Delivery fee</h2><div class="skel"></div><br><div class="skel" style="width:70%"></div>`;
    try { const q = await api("/merchant/orders/quote", { method: "POST", json: o }); if (key !== lastKey) return; const x = q.fee;
      $("#fee").innerHTML = `<h2>Delivery fee</h2><small>Zone: ${esc(q.zone)} · ${x.distance_km} km</small><ul><li>Base <span>${money(x.base, x.currency)}</span></li><li>Distance <span>${money(x.distance_fee, x.currency)}</span></li>
        <li>Weight <span>${money(x.weight_fee, x.currency)}</span></li>${x.cod_fee ? `<li>COD handling <span>${money(x.cod_fee, x.currency)}</span></li>` : ""}${x.slot_surcharge ? `<li>Peak slot <span>${money(x.slot_surcharge, x.currency)}</span></li>` : ""}</ul>
        <div class="total"><span>Total</span><span>${money(x.total, x.currency)}</span></div>${pm === "epayment" ? `<p class="muted">You'll pay this online after submitting.</p>` : `<p class="muted">Deducted from your COD payout.</p>`}<button class="btn block" id="go">Create delivery order</button>`;
      $("#go").onclick = submit;
    } catch (x) { showErr({ ...x.fields }); $("#fee").innerHTML = `<h2>Delivery fee</h2><div class="err" role="alert">${esc(x.message)}</div>`; lastKey = ""; }
  }
  async function submit() { const b = $("#go"); b.disabled = true; b.textContent = "Creating…";
    try { const r = await api("/merchant/orders", { method: "POST", json: val() }); toast(`Order ${r.order.order_number} created`); if (r.payment_url) toast("Complete the payment to release it for dispatch"); location.hash = "orders"; }
    catch (x) { toast(x.message, true); showErr(x.fields); b.disabled = false; b.textContent = "Create delivery order"; lastKey = ""; } }
  async function loadSlots() { slot = null; $("#slots").innerHTML = `<div class="skel" style="grid-column:1/-1"></div>`;
    try { const s = await api("/merchant/time-slots?date=" + f.delivery_date.value); $("#slots").innerHTML = s.map((x) => `<button type="button" class="choice" role="radio" data-id="${x.id}" ${x.available ? "" : "disabled"}><b>${esc(x.label)}</b><small>${x.available ? (x.surcharge ? "+" + money(x.surcharge) : "Standard") : "Fully booked"}</small></button>`).join("");
      $$("#slots .choice").forEach((c) => (c.onclick = () => { slot = +c.dataset.id; $$("#slots .choice").forEach((n) => n.classList.toggle("on", n === c)); touched.add("time_slot_id"); refresh(); })); } catch (x) { toast(x.message, true); } refresh(); }
  $$("[data-pm]").forEach((b) => (b.onclick = () => { pm = b.dataset.pm; $$("[data-pm]").forEach((n) => n.classList.toggle("on", n === b)); $("#codw").style.display = pm === "cod" ? "" : "none"; refresh(); }));
  f.addEventListener("input", (e) => { touched.add(e.target.name === "dropoff_pin" ? "dropoff_lat" : e.target.name); clearTimeout(refresh.t); refresh.t = setTimeout(refresh, 350); });
  f.delivery_date.addEventListener("change", loadSlots); f.onsubmit = (e) => e.preventDefault(); loadSlots();
}

/* ---------- merchant: orders (live) ---------- */
function ordersView() {
  let group = "active", q = "";
  shell("orders", "Orders", "Live — updates every few seconds", `<div class="card"><div class="head"><div class="seg" role="tablist">${["active", "delivered", "closed"].map((g) => `<button role="tab" data-g="${g}" class="${g === group ? "on" : ""}">${g[0].toUpperCase() + g.slice(1)}</button>`).join("")}</div>
    <input id="q" placeholder="Search order #, name, phone" style="max-width:280px" aria-label="Search orders"></div><div class="scroll" id="tbl"></div></div>`);
  async function load() { try { const { items } = await api(`/merchant/orders?group=${group}&q=${encodeURIComponent(q)}`);
    $("#tbl").innerHTML = items.length ? `<table><thead><tr><th>Order</th><th>Customer</th><th>Slot</th><th>Payment</th><th>Status</th><th>Fee</th><th></th></tr></thead><tbody>${items.map((o) => `<tr>
      <td><b>${esc(o.order_number)}</b><br><small>${new Date(o.created_at).toLocaleString()}</small></td><td>${esc(o.customer_name)}<br><small>${esc(o.dropoff_address)}</small></td>
      <td>${esc(o.delivery_date)}<br><small>${esc(o.slot_label)}</small></td><td>${o.payment_method === "cod" ? "COD " + money(o.cod_amount) : "E-payment"}<br><small>${esc(o.payment_status)}</small></td>
      <td>${pill(o.status)}${o.driver_name ? `<br><small>${esc(o.driver_name)}${o.driver_lat ? ` · <a target="_blank" rel="noopener" href="https://maps.google.com/?q=${o.driver_lat},${o.driver_lng}">📍 live</a>` : ""}</small>` : ""}</td>
      <td>${money(o.delivery_fee)}</td><td>${["awaiting_payment", "pending", "assigned", "accepted"].includes(o.status) ? `<button class="btn ghost sm" data-c="${o.id}">Cancel</button>` : ""}</td></tr>`).join("")}</tbody></table>` : `<div class="empty">No ${group} orders${q ? " match your search" : " yet"}.</div>`;
    $$("[data-c]").forEach((b) => (b.onclick = async () => { if (confirm("Cancel this order?")) { try { await api(`/merchant/orders/${b.dataset.c}/cancel`, { method: "POST" }); toast("Order cancelled"); load(); } catch (x) { toast(x.message, true); } } })); } catch (x) { toast(x.message, true); } }
  $$("[data-g]").forEach((b) => (b.onclick = () => { group = b.dataset.g; $$("[data-g]").forEach((n) => n.classList.toggle("on", n === b)); load(); }));
  $("#q").oninput = (e) => { q = e.target.value; clearTimeout(load.t); load.t = setTimeout(load, 300); }; poll(load, 5000);
}

/* ---------- admin: dispatch ---------- */
function dispatchView() {
  shell("dispatch", "Dispatch", "Assign pending orders to drivers", `<div class="kpis" id="k"></div><div class="grid2"><div class="card"><h2>Unassigned queue</h2><div id="queue"></div></div><div class="card"><h2>Drivers online</h2><div id="drv"></div></div></div>`);
  let drivers = [];
  async function load() { try { const [{ items }, d] = await Promise.all([api("/admin/orders?unassigned=1"), api("/admin/drivers/live")]); drivers = d;
    $("#k").innerHTML = [["Waiting", items.length], ["Drivers online", d.length], ["Free", d.filter((x) => x.status === "available").length], ["Busy", d.filter((x) => x.status === "busy").length]].map(([t, n]) => `<div class="card kpi"><small>${t}</small><b>${n}</b></div>`).join("");
    $("#queue").innerHTML = items.length ? items.map((o) => `<div class="ocard" style="padding:12px 0;border-bottom:1px solid var(--line)"><div class="row"><b>${esc(o.order_number)}</b><span class="muted">${esc(o.slot_label)} · ${o.payment_method === "cod" ? "COD " + money(o.cod_amount) : "Prepaid"}</span></div>
      <div class="route"><small>${esc(o.pickup_address)}</small><small>→ ${esc(o.dropoff_address)}</small></div><div class="row"><button class="btn sm" data-a="${o.id}">Auto-assign</button>
      <select data-m="${o.id}" aria-label="Assign manually"><option value="">Assign manually…</option>${d.filter((x) => x.zone_id === o.zone_id).map((x) => `<option value="${x.driver_id}">${esc(x.name)} (${x.status}, ${x.active_orders})</option>`).join("")}</select></div></div>`).join("") : `<div class="empty">🎉 Nothing waiting — all orders are covered.</div>`;
    $("#drv").innerHTML = d.length ? `<table><tbody>${d.map((x) => `<tr><td><b>${esc(x.name)}</b><br><small>${x.active_orders} active</small></td><td><span class="pill s-${x.status === "available" ? "delivered" : "pending"}">${esc(x.status)}</span></td><td><a target="_blank" rel="noopener" href="https://maps.google.com/?q=${x.lat},${x.lng}">📍 map</a></td></tr>`).join("")}</tbody></table>` : `<div class="empty">No drivers online.</div>`;
    $$("[data-a]").forEach((b) => (b.onclick = () => act(`/admin/orders/${b.dataset.a}/auto-dispatch`, {})));
    $$("[data-m]").forEach((s) => (s.onchange = () => s.value && act(`/admin/orders/${s.dataset.m}/assign`, { driver_id: s.value }))); } catch (x) { toast(x.message, true); } }
  async function act(p, json) { try { await api(p, { method: "POST", json }); toast("Order dispatched"); } catch (x) { toast(x.message, true); } load(); }
  poll(load, 5000);
}

/* ---------- admin: reports ---------- */
function reportsView() {
  let g = "day"; const R = { day: 14, week: 90, month: 365 };
  shell("reports", "Reports", "Revenue and driver performance", `<div class="head"><div class="seg">${["day", "week", "month"].map((x) => `<button data-g="${x}" class="${x === g ? "on" : ""}">${x === "day" ? "Daily" : x === "week" ? "Weekly" : "Monthly"}</button>`).join("")}</div><button class="btn ghost" id="csv">Export CSV</button></div>
    <div class="kpis" id="k"></div><div class="card" style="margin-bottom:20px"><h2>Delivery revenue vs COD collected</h2><div id="chart"></div></div><div class="card scroll"><h2>Driver performance</h2><div id="perf"></div></div>`);
  let rev = [];
  async function load() { const end = new Date(), start = new Date(Date.now() - R[g] * 864e5), qs = `start=${iso(start)}&end=${iso(end)}`;
    try { [rev] = await Promise.all([api(`/admin/reports/revenue?granularity=${g}&${qs}`)]); const perf = await api(`/admin/reports/performance?${qs}`);
      const sum = (k) => rev.reduce((a, r) => a + +r[k], 0), max = Math.max(1, ...rev.map((r) => Math.max(r.delivery_revenue, r.cod_collected)));
      $("#k").innerHTML = [["Orders delivered", sum("orders")], ["Delivery revenue", money(sum("delivery_revenue"))], ["COD collected", money(sum("cod_collected"))], ["E-payment orders", sum("epayment_orders")]].map(([t, n]) => `<div class="card kpi"><small>${t}</small><b>${n}</b></div>`).join("");
      $("#chart").innerHTML = rev.length ? `<div class="bars">${rev.map((r) => `<div class="bar" title="${esc(r.period.slice(0, 10))}: ${money(r.delivery_revenue)} revenue, ${money(r.cod_collected)} COD"><div class="pair"><i style="height:${(r.delivery_revenue / max) * 100}%"></i><i class="cod" style="height:${(r.cod_collected / max) * 100}%"></i></div>${esc(g === "month" ? r.period.slice(0, 7) : r.period.slice(5, 10))}</div>`).join("")}</div>` : `<div class="empty">No deliveries in this period.</div>`;
      $("#perf").innerHTML = perf.length ? `<table><thead><tr><th>Driver</th><th>Delivered</th><th>Failed</th><th>Avg min</th><th>COD outstanding</th></tr></thead><tbody>${perf.map((d) => `<tr><td><b>${esc(d.name)}</b></td><td>${d.delivered}</td><td>${d.failed}</td><td>${d.avg_delivery_minutes ?? "—"}</td><td>${money(d.cod_outstanding)}</td></tr>`).join("")}</tbody></table>` : `<div class="empty">No driver activity in this period.</div>`;
    } catch (x) { toast(x.message, true); } }
  $$("[data-g]").forEach((b) => (b.onclick = () => { g = b.dataset.g; $$("[data-g]").forEach((n) => n.classList.toggle("on", n === b)); load(); }));
  $("#csv").onclick = () => { const t = ["period,orders,delivery_revenue,cod_collected,epayment_orders", ...rev.map((r) => [r.period.slice(0, 10), r.orders, r.delivery_revenue, r.cod_collected, r.epayment_orders].join(","))].join("\n");
    Object.assign(document.createElement("a"), { href: URL.createObjectURL(new Blob([t], { type: "text/csv" })), download: `revenue-${g}.csv` }).click(); }; load();
}

/* ---------- driver ---------- */
function driverView() {
  let online = false, watch = null, pos = null, lastSent = 0;
  shell("jobs", "My jobs", "Go online to receive orders in your zone", `<div class="card" style="margin-bottom:16px"><label class="switch"><input type="checkbox" id="on" role="switch"> <span id="st">Offline</span></label></div><div class="stack"><div id="act"></div><div id="av"></div></div>`);
  const send = (p) => { pos = p.coords; if (Date.now() - lastSent > 8000) { lastSent = Date.now(); api("/driver/location", { method: "POST", json: { lat: pos.latitude, lng: pos.longitude, heading: pos.heading, speed_kmh: pos.speed ? pos.speed * 3.6 : null } }).catch(() => {}); } };
  $("#on").onchange = async (e) => { try { if (e.target.checked) { if (!navigator.geolocation) throw new Error("Location is not available on this device"); watch = navigator.geolocation.watchPosition(send, () => toast("Location permission is needed", true), { enableHighAccuracy: true }); await api("/driver/status", { method: "POST", json: { status: "available" } }); }
      else { navigator.geolocation.clearWatch(watch); await api("/driver/status", { method: "POST", json: { status: "offline" } }); } online = e.target.checked; $("#st").textContent = online ? "Online" : "Offline"; load(); } catch (x) { e.target.checked = false; toast(x.message, true); } };
  const card = (o, mode) => `<div class="card ocard"><div class="row"><b>${esc(o.order_number)}</b>${pill(o.status)}</div><div class="route"><small>Pickup · ${esc(o.pickup.address)}</small><small>Dropoff · ${esc(o.dropoff.address)}</small></div>
    <div class="row"><small>${esc(o.slot_label)}${o.distance_from_driver_km != null ? ` · ${o.distance_from_driver_km} km away` : ""}</small><b>${o.cod_to_collect ? "Collect " + money(o.cod_to_collect) : "Prepaid"}</b></div>
    <div class="row">${mode === "av" ? `<button class="btn" data-acc="${o.id}">Accept</button>` : `<a class="btn ghost" target="_blank" rel="noopener" href="${esc(o.navigate_url)}">🧭 Navigate</a>${o.status === "accepted" ? `<button class="btn" data-pk="${o.id}">Picked up</button>` : `<button class="btn" data-dl="${o.id}" data-cod="${o.cod_to_collect}">Deliver</button><button class="btn danger sm" data-fl="${o.id}">Failed</button>`}`}</div></div>`;
  async function load() { if (!online) return; try { const [a, v] = await Promise.all([api("/driver/orders/active"), api("/driver/orders/available")]);
    $("#act").innerHTML = a.length ? `<h2>In progress</h2><div class="stack">${a.map((o) => card(o, "act")).join("")}</div>` : ""; $("#av").innerHTML = `<h2>Available nearby</h2>` + (v.length ? `<div class="stack">${v.map((o) => card(o, "av")).join("")}</div>` : `<div class="card empty">No orders right now — we'll refresh automatically.</div>`);
    $$("[data-acc]").forEach((b) => (b.onclick = () => run(`/driver/orders/${b.dataset.acc}/accept`)));
    $$("[data-pk]").forEach((b) => (b.onclick = () => run(`/driver/orders/${b.dataset.pk}/pickup`))); $$("[data-fl]").forEach((b) => (b.onclick = () => { const r = prompt("Why could the delivery not be completed?"); r && run(`/driver/orders/${b.dataset.fl}/fail`, { reason: r }); }));
    $$("[data-dl]").forEach((b) => (b.onclick = () => deliverModal(b.dataset.dl, +b.dataset.cod))); } catch (x) { toast(x.message, true); } }
  async function run(p, json) { try { await api(p, { method: "POST", json }); load(); } catch (x) { toast(x.message, true); load(); } }
  function deliverModal(id, cod) { const m = document.createElement("div"); m.className = "modal"; m.innerHTML = `<form class="card stack"><h2>Confirm delivery</h2>${cod ? `<div class="card" style="background:var(--warn-soft)"><b>Collect ${money(cod)} in cash</b><br><label style="display:flex;gap:8px;align-items:center;margin-top:8px"><input type="checkbox" name="cash" style="width:auto;min-height:0"> I received the full amount</label></div>` : ""}
    <label>Customer OTP <span class="opt">(4 digits)</span><input name="otp" inputmode="numeric" maxlength="4" autocomplete="one-time-code"></label><label>…or photo proof<input type="file" name="photo" accept="image/*" capture="environment"></label>
    <div class="err" id="e" role="alert"></div><div class="row"><button type="button" class="btn ghost" id="x">Cancel</button><button class="btn">Confirm</button></div></form>`; document.body.append(m); $("#x", m).onclick = () => m.remove();
    $("form", m).onsubmit = async (e) => { e.preventDefault(); const f = e.target; if (cod && !f.cash.checked) return ($("#e", m).textContent = "Confirm you collected the cash");
      const fd = new FormData(); fd.set("lat", pos?.latitude ?? ""); fd.set("lng", pos?.longitude ?? ""); fd.set("cod_collected", cod); if (f.otp.value) fd.set("otp", f.otp.value); if (f.photo.files[0]) fd.set("photo", f.photo.files[0]);
      try { await api(`/driver/orders/${id}/deliver`, { method: "POST", form: fd }); m.remove(); toast("Delivered ✔"); load(); } catch (x) { $("#e", m).textContent = x.message; } }; }
  poll(load, 8000);
}

/* ---------- router ---------- */
function route() {
  clearTimers(); if (!S.token) return loginView();
  const k = location.hash.slice(1), def = { merchant: "orders", admin: "dispatch", driver: "jobs" }[S.role];
  const views = { new: newOrderView, orders: ordersView, dispatch: dispatchView, reports: reportsView, jobs: driverView };
  const v = NAV[S.role].some(([n]) => n === k) ? k : def; if (v !== k) { location.hash = v; return; } views[v]();
}
addEventListener("hashchange", route); route();
