<?php
declare(strict_types=1);
require __DIR__ . '/../src/bootstrap.php';
require __DIR__ . '/../src/handlers.php';

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH); $method = $_SERVER['REQUEST_METHOD'];
if (!str_starts_with($path, '/api/')) { if (!is_file(__DIR__ . $path) || is_dir(__DIR__ . $path)) readfile(__DIR__ . '/index.html'); else return false; exit; }

header('Access-Control-Allow-Origin: ' . (env('CORS_ORIGIN', '*'))); header('Access-Control-Allow-Headers: Authorization, Content-Type'); header('Access-Control-Allow-Methods: GET,POST,OPTIONS');
if ($method === 'OPTIONS') { http_response_code(204); exit; }

$routes = [
    ['POST', '#^/api/auth/login$#', 'h_login'],
    ['GET',  '#^/api/merchant/time-slots$#', 'h_slots'],
    ['POST', '#^/api/merchant/orders/quote$#', 'h_quote'],
    ['POST', '#^/api/merchant/orders$#', 'h_create_order'],
    ['GET',  '#^/api/merchant/orders$#', 'h_merchant_orders'],
    ['POST', '#^/api/merchant/orders/([0-9a-f-]{36})/cancel$#', 'h_merchant_cancel'],
    ['POST', '#^/api/driver/status$#', 'h_driver_status'],
    ['POST', '#^/api/driver/location$#', 'h_driver_location'],
    ['GET',  '#^/api/driver/orders/available$#', 'h_driver_available'],
    ['GET',  '#^/api/driver/orders/active$#', 'h_driver_active'],
    ['POST', '#^/api/driver/orders/([0-9a-f-]{36})/accept$#', 'h_driver_accept'],
    ['POST', '#^/api/driver/orders/([0-9a-f-]{36})/release$#', 'h_driver_release'],
    ['POST', '#^/api/driver/orders/([0-9a-f-]{36})/pickup$#', 'h_driver_pickup'],
    ['POST', '#^/api/driver/orders/([0-9a-f-]{36})/fail$#', 'h_driver_fail'],
    ['POST', '#^/api/driver/orders/([0-9a-f-]{36})/deliver$#', 'h_driver_deliver'],
    ['GET',  '#^/api/admin/drivers/live$#', 'h_admin_live'],
    ['GET',  '#^/api/admin/orders$#', 'h_admin_orders'],
    ['POST', '#^/api/admin/orders/([0-9a-f-]{36})/assign$#', 'h_admin_assign'],
    ['POST', '#^/api/admin/orders/([0-9a-f-]{36})/auto-dispatch$#', 'h_admin_auto'],
    ['GET',  '#^/api/admin/reports/revenue$#', 'h_admin_revenue'],
    ['GET',  '#^/api/admin/reports/performance$#', 'h_admin_performance'],
];
try {
    foreach ($routes as [$m, $re, $fn]) if ($m === $method && preg_match($re, $path, $mm)) $fn(...array_slice($mm, 1));
    throw new HttpError(404, 'Route not found');
} catch (HttpError $e) {
    out(['error' => $e->getMessage(), 'fields' => (object)$e->fields], $e->status);
} catch (Throwable $e) {
    error_log((string)$e); out(['error' => 'Server error'], 500);
}
