-- =====================================================================
-- Courier & Delivery Platform — PostgreSQL 14+ schema
-- =====================================================================
CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- gen_random_uuid()

-- ---------- Enums ----------------------------------------------------
CREATE TYPE user_role      AS ENUM ('merchant', 'driver', 'admin');
CREATE TYPE driver_status  AS ENUM ('offline', 'available', 'busy');
CREATE TYPE payment_method AS ENUM ('cod', 'epayment');
CREATE TYPE payment_status AS ENUM ('not_required', 'pending', 'paid', 'failed', 'refunded');
CREATE TYPE order_status   AS ENUM ('awaiting_payment', 'pending', 'assigned', 'accepted',
                                    'picked_up', 'delivered', 'failed', 'cancelled');
CREATE TYPE cod_status     AS ENUM ('with_driver', 'remitted', 'settled_to_merchant');
CREATE TYPE pod_type       AS ENUM ('photo', 'signature', 'otp');

CREATE SEQUENCE order_number_seq START 1;

-- ---------- Generic updated_at trigger ------------------------------
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$ LANGUAGE plpgsql;

-- ---------- Users ----------------------------------------------------
CREATE TABLE users (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email         TEXT UNIQUE NOT NULL,
    phone         TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name     TEXT NOT NULL,
    role          user_role NOT NULL,
    is_active     BOOLEAN NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TRIGGER trg_users_updated BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------- Zones (dispatch areas) ----------------------------------
CREATE TABLE zones (
    id         SERIAL PRIMARY KEY,
    name       TEXT UNIQUE NOT NULL,
    center_lat DOUBLE PRECISION NOT NULL CHECK (center_lat BETWEEN -90 AND 90),
    center_lng DOUBLE PRECISION NOT NULL CHECK (center_lng BETWEEN -180 AND 180),
    radius_km  NUMERIC(6,2) NOT NULL CHECK (radius_km > 0),
    is_active  BOOLEAN NOT NULL DEFAULT TRUE
);

-- ---------- Merchants -------------------------------------------------
CREATE TABLE merchants (
    id                     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id                UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    business_name          TEXT NOT NULL,
    default_pickup_address TEXT,
    default_pickup_lat     DOUBLE PRECISION,
    default_pickup_lng     DOUBLE PRECISION,
    is_approved            BOOLEAN NOT NULL DEFAULT FALSE,
    created_at             TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Drivers ---------------------------------------------------
CREATE TABLE drivers (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id          UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    zone_id          INT REFERENCES zones(id),
    vehicle_type     TEXT NOT NULL DEFAULT 'motorbike',
    vehicle_plate    TEXT,
    status           driver_status NOT NULL DEFAULT 'offline',
    current_lat      DOUBLE PRECISION,
    current_lng      DOUBLE PRECISION,
    last_location_at TIMESTAMPTZ,
    is_approved      BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_drivers_zone_status ON drivers (zone_id, status);

-- ---------- Delivery time slots --------------------------------------
CREATE TABLE time_slots (
    id         SERIAL PRIMARY KEY,
    label      TEXT NOT NULL,
    start_time TIME NOT NULL,
    end_time   TIME NOT NULL,
    capacity   INT  NOT NULL CHECK (capacity > 0),      -- max orders per slot per day
    surcharge  NUMERIC(10,2) NOT NULL DEFAULT 0,        -- peak / express slot fee
    is_active  BOOLEAN NOT NULL DEFAULT TRUE,
    CHECK (end_time > start_time)
);

-- ---------- Orders ----------------------------------------------------
CREATE TABLE orders (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_number    TEXT UNIQUE NOT NULL,
    merchant_id     UUID NOT NULL REFERENCES merchants(id),
    driver_id       UUID REFERENCES drivers(id),
    zone_id         INT  NOT NULL REFERENCES zones(id),

    -- pickup
    pickup_address       TEXT NOT NULL,
    pickup_lat           DOUBLE PRECISION NOT NULL,
    pickup_lng           DOUBLE PRECISION NOT NULL,
    pickup_contact_name  TEXT,
    pickup_contact_phone TEXT,

    -- customer / dropoff
    customer_name   TEXT NOT NULL,
    customer_phone  TEXT NOT NULL,
    dropoff_address TEXT NOT NULL,
    dropoff_lat     DOUBLE PRECISION NOT NULL,
    dropoff_lng     DOUBLE PRECISION NOT NULL,
    notes           TEXT,

    -- parcel
    package_description TEXT,
    weight_kg       NUMERIC(6,2) NOT NULL DEFAULT 1 CHECK (weight_kg > 0 AND weight_kg <= 50),

    -- schedule
    delivery_date   DATE NOT NULL,
    time_slot_id    INT  NOT NULL REFERENCES time_slots(id),

    -- payment
    payment_method  payment_method NOT NULL,
    payment_status  payment_status NOT NULL,
    cod_amount      NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (cod_amount >= 0),
    CONSTRAINT cod_amount_consistency CHECK (
        (payment_method = 'cod'      AND cod_amount > 0) OR
        (payment_method = 'epayment' AND cod_amount = 0)
    ),

    -- fee snapshot at creation (audit)
    distance_km     NUMERIC(8,2)  NOT NULL,
    delivery_fee    NUMERIC(10,2) NOT NULL,
    fee_breakdown   JSONB NOT NULL,

    -- lifecycle
    status          order_status NOT NULL,
    delivery_otp    CHAR(4) NOT NULL,
    failure_reason  TEXT,
    assigned_at     TIMESTAMPTZ,
    accepted_at     TIMESTAMPTZ,
    picked_up_at    TIMESTAMPTZ,
    delivered_at    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TRIGGER trg_orders_updated BEFORE UPDATE ON orders
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE INDEX idx_orders_merchant_created ON orders (merchant_id, created_at DESC);
CREATE INDEX idx_orders_driver_status    ON orders (driver_id, status);
CREATE INDEX idx_orders_dispatch         ON orders (zone_id, status) WHERE status IN ('pending','assigned');
CREATE INDEX idx_orders_slot_capacity    ON orders (delivery_date, time_slot_id) WHERE status <> 'cancelled';
CREATE INDEX idx_orders_delivered_at     ON orders (delivered_at) WHERE status = 'delivered';

-- ---------- Order audit trail ---------------------------------------
CREATE TABLE order_events (
    id            BIGSERIAL PRIMARY KEY,
    order_id      UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    from_status   order_status,
    to_status     order_status NOT NULL,
    actor_user_id UUID REFERENCES users(id),
    note          TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_order_events_order ON order_events (order_id, created_at);

-- ---------- Proof of delivery ----------------------------------------
CREATE TABLE proofs_of_delivery (
    id             BIGSERIAL PRIMARY KEY,
    order_id       UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    driver_id      UUID NOT NULL REFERENCES drivers(id),
    type           pod_type NOT NULL,
    file_url       TEXT,                 -- photo / signature image
    otp_value      CHAR(4),              -- when type = 'otp'
    recipient_name TEXT,
    lat            DOUBLE PRECISION,
    lng            DOUBLE PRECISION,
    captured_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_pod_order ON proofs_of_delivery (order_id);

-- ---------- Payments (e-payment gateway records) ---------------------
CREATE TABLE payments (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id     UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    method       payment_method NOT NULL,
    amount       NUMERIC(12,2) NOT NULL CHECK (amount >= 0),
    status       payment_status NOT NULL,
    provider     TEXT,
    provider_ref TEXT UNIQUE,            -- gateway txn id (idempotency key)
    paid_at      TIMESTAMPTZ,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_payments_order ON payments (order_id);

-- ---------- COD cash tracking -----------------------------------------
-- with_driver -> remitted (driver hands cash to company) -> settled_to_merchant
CREATE TABLE cod_collections (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id     UUID UNIQUE NOT NULL REFERENCES orders(id),
    driver_id    UUID NOT NULL REFERENCES drivers(id),
    merchant_id  UUID NOT NULL REFERENCES merchants(id),
    amount       NUMERIC(12,2) NOT NULL CHECK (amount > 0),
    status       cod_status NOT NULL DEFAULT 'with_driver',
    collected_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    remitted_at  TIMESTAMPTZ,
    settled_at   TIMESTAMPTZ
);
CREATE INDEX idx_cod_status_driver ON cod_collections (status, driver_id);
CREATE INDEX idx_cod_merchant      ON cod_collections (merchant_id, status);

-- ---------- Driver GPS history (live map + audit) -------------------
CREATE TABLE driver_locations (
    id          BIGSERIAL PRIMARY KEY,
    driver_id   UUID NOT NULL REFERENCES drivers(id) ON DELETE CASCADE,
    lat         DOUBLE PRECISION NOT NULL,
    lng         DOUBLE PRECISION NOT NULL,
    heading     REAL,
    speed_kmh   REAL,
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_driver_loc_latest ON driver_locations (driver_id, recorded_at DESC);

-- ---------- Seed data -------------------------------------------------
INSERT INTO time_slots (label, start_time, end_time, capacity, surcharge) VALUES
 ('Morning 09:00-12:00',   '09:00', '12:00', 60, 0),
 ('Afternoon 12:00-15:00', '12:00', '15:00', 60, 0),
 ('Evening 15:00-18:00',   '15:00', '18:00', 60, 0.50),
 ('Night 18:00-21:00',     '18:00', '21:00', 40, 1.00);
