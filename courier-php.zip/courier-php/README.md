# Courier Platform — PHP 8.1+ & JSON edition

Same PostgreSQL schema as the FastAPI version (`schema.sql`), implemented as a dependency-free PHP JSON API plus a responsive web UI
(merchant portal, admin dashboard, driver web app). Needs PHP 8.1+ with `pdo_pgsql` and `fileinfo`.

```bash
createdb courier && psql courier -f schema.sql
cp .env.example .env            # set DB + JWT_SECRET
php bin/seed.php                # zone + demo admin/merchant/driver (change passwords!)
php -S localhost:8080 -t public public/index.php
# open http://localhost:8080
```
Production: nginx/Apache pointing at `public/`, rewrite everything not a real file to `index.php`, HTTPS, and block direct execution inside `uploads/`.

## Layout
`public/index.php` router · `src/bootstrap.php` (DB, JWT, validation, fees, state machine) · `src/handlers.php` (all endpoints) · `public/assets/app.{css,js}` UI.

## JSON API (all under `/api`, `Authorization: Bearer <jwt>`; errors → `{"error":"…","fields":{"field":"msg"}}`)
| Role | Endpoint |
|---|---|
| any | `POST /auth/login {email,password}` → `{access_token, role, name}` |
| merchant | `GET /merchant/time-slots?date=` · `POST /merchant/orders/quote` · `POST /merchant/orders` · `GET /merchant/orders?group=active\|delivered\|closed&q=` · `POST /merchant/orders/{id}/cancel` |
| driver | `POST /driver/status` · `POST /driver/location` · `GET /driver/orders/available?radius_km=` · `GET /driver/orders/active` · `POST /driver/orders/{id}/accept\|release\|pickup\|fail\|deliver` |
| admin | `GET /admin/drivers/live` · `GET /admin/orders?unassigned=1` · `POST /admin/orders/{id}/assign {driver_id}` · `POST /admin/orders/{id}/auto-dispatch` · `GET /admin/reports/revenue?granularity=day\|week\|month&start&end` · `GET /admin/reports/performance` |

Create order request:
```json
{ "customer_name":"Sara Ali","customer_phone":"+9647501234567","dropoff_address":"Street 12, Block 4","dropoff_lat":36.205,"dropoff_lng":44.021,
  "weight_kg":2.5,"delivery_date":"2026-10-26","time_slot_id":2,"payment_method":"cod","cod_amount":45.00,"notes":"Call on arrival" }
```
Response `201`: `{"order":{…},"fee":{"currency":"USD","distance_km":…,"base":3,"distance_fee":…,"weight_fee":0,"cod_fee":0.68,"slot_surcharge":0,"total":…},"payment_url":null}`

Deliver (multipart): `lat, lng, cod_collected, otp?, recipient_name?, photo?, signature?` → `{"order_id":"…","status":"delivered","cod_collected":45,"proofs":["/uploads/pod/…jpg"]}`

## Notes
- Rules mirror the Python version: slot capacity under row lock, atomic order claim, exact-COD check, POD required (photo/signature/OTP + GPS), e-payment orders held in `awaiting_payment`.
- PHP has no native WebSockets, so the UI polls every 5–8 s. For true push, add an SSE endpoint or a Ratchet/Swoole service.
- Not executed against a live database in my sandbox (no PHP/PostgreSQL available there). Run it against a test DB first; the e-payment webhook and SMS OTP are still stubs.
- Optional: wire Google Places for address → pin; right now pins are entered as “lat, lng” (right-click in Google Maps → copy).
