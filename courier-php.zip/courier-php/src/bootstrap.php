<?php
declare(strict_types=1);

// ---------- env ----------
foreach (@file(__DIR__ . '/../.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $l) {
    if ($l[0] !== '#' && str_contains($l, '=')) { [$k, $v] = explode('=', $l, 2); $_ENV[trim($k)] = trim($v, " \"'"); }
}
function env(string $k, string $d = ''): string { return $_ENV[$k] ?? getenv($k) ?: $d; }
date_default_timezone_set(env('BUSINESS_TZ', 'UTC'));

// ---------- config (pricing & dispatch rules) ----------
const CFG = ['base_fee' => 3.00, 'included_km' => 3.0, 'per_km' => 0.50, 'weight_free_kg' => 5.0, 'per_kg' => 0.30,
             'cod_pct' => 0.015, 'cod_min' => 0.50, 'road_factor' => 1.3, 'max_km' => 40.0,
             'slot_lead_min' => 60, 'max_days_ahead' => 7, 'max_active_per_driver' => 5];

function db(): PDO {
    static $pdo;
    return $pdo ??= new PDO(env('DB_DSN'), env('DB_USER'), env('DB_PASS'), [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]);
}
function q(string $sql, array $p = []): PDOStatement { $s = db()->prepare($sql); $s->execute($p); return $s; }

// ---------- http helpers ----------
class HttpError extends Exception { public function __construct(public int $status, string $msg, public array $fields = []) { parent::__construct($msg); } }
function out(mixed $data, int $status = 200): never {
    http_response_code($status); header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION); exit;
}
function body(): array {
    if (str_contains($_SERVER['CONTENT_TYPE'] ?? '', 'multipart')) return $_POST;
    $j = json_decode(file_get_contents('php://input') ?: '', true);
    return is_array($j) ? $j : [];
}

// ---------- JWT (HS256) ----------
function b64u(string $s): string { return rtrim(strtr(base64_encode($s), '+/', '-_'), '='); }
function jwt_encode(array $c): string {
    $h = b64u(json_encode(['alg' => 'HS256', 'typ' => 'JWT'])); $p = b64u(json_encode($c));
    return "$h.$p." . b64u(hash_hmac('sha256', "$h.$p", env('JWT_SECRET'), true));
}
function jwt_decode(string $t): array {
    $x = explode('.', $t); if (count($x) !== 3) throw new HttpError(401, 'Invalid token');
    if (!hash_equals(b64u(hash_hmac('sha256', "$x[0].$x[1]", env('JWT_SECRET'), true)), $x[2])) throw new HttpError(401, 'Invalid token');
    $c = json_decode(base64_decode(strtr($x[1], '-_', '+/')), true);
    if (($c['exp'] ?? 0) < time()) throw new HttpError(401, 'Token expired');
    return $c;
}
function auth(string $role): array {
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? (function_exists('apache_request_headers') ? (apache_request_headers()['Authorization'] ?? '') : '');
    if (!preg_match('/^Bearer (.+)$/', $h, $m)) throw new HttpError(401, 'Missing token');
    $c = jwt_decode($m[1]);
    if ($c['role'] !== $role) throw new HttpError(403, "$role role required");
    $u = q('SELECT * FROM users WHERE id = ? AND is_active', [$c['sub']])->fetch();
    if (!$u) throw new HttpError(401, 'User inactive');
    return $u;
}

// ---------- validation ----------
function validate_order(array $b): array {
    $e = []; $d = [];
    $s = fn($k, $min, $max) => is_string($b[$k] ?? null) && mb_strlen(trim($b[$k])) >= $min && mb_strlen(trim($b[$k])) <= $max;
    $phone = fn($v) => is_string($v) && preg_match('/^\+?[0-9]{8,15}$/', preg_replace('/[\s-]/', '', $v));
    if (!$s('customer_name', 2, 120)) $e['customer_name'] = 'Enter the customer name (2–120 chars)';
    if (!$phone($b['customer_phone'] ?? null)) $e['customer_phone'] = 'Use international format, e.g. +9647501234567';
    if (!$s('dropoff_address', 5, 300)) $e['dropoff_address'] = 'Address is too short';
    foreach (['dropoff_lat' => 90, 'dropoff_lng' => 180] as $k => $lim)
        if (!is_numeric($b[$k] ?? null) || abs((float)$b[$k]) > $lim) $e[$k] = 'Invalid coordinate';
    $w = $b['weight_kg'] ?? 1; if (!is_numeric($w) || $w <= 0 || $w > 50) $e['weight_kg'] = 'Weight must be 0.1–50 kg';
    $date = $b['delivery_date'] ?? ''; if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !strtotime($date)) $e['delivery_date'] = 'Invalid date';
    if (!is_numeric($b['time_slot_id'] ?? null)) $e['time_slot_id'] = 'Choose a time slot';
    $pm = $b['payment_method'] ?? ''; $cod = (float)($b['cod_amount'] ?? 0);
    if (!in_array($pm, ['cod', 'epayment'], true)) $e['payment_method'] = 'Choose COD or E-Payment';
    elseif ($pm === 'cod' && $cod <= 0) $e['cod_amount'] = 'Enter the amount to collect';
    elseif ($pm === 'epayment' && $cod != 0) $e['cod_amount'] = 'COD amount must be 0 for e-payment';
    if (!empty($b['pickup_address']) && (!is_numeric($b['pickup_lat'] ?? null) || !is_numeric($b['pickup_lng'] ?? null))) $e['pickup_address'] = 'Pickup coordinates required with a custom address';
    if ($e) throw new HttpError(422, 'Validation failed', $e);
    return $b;
}

// ---------- geo & fees ----------
function haversine_km(float $a1, float $o1, float $a2, float $o2): float {
    $p1 = deg2rad($a1); $p2 = deg2rad($a2); $dp = $p2 - $p1; $dl = deg2rad($o2 - $o1);
    return 2 * 6371.0088 * asin(sqrt(sin($dp / 2) ** 2 + cos($p1) * cos($p2) * sin($dl / 2) ** 2));
}
function calc_fee(float $km, float $kg, string $method, float $cod, float $surcharge): array {
    $dist = round(max(0, $km - CFG['included_km']) * CFG['per_km'], 2);
    $wt   = round(max(0, $kg - CFG['weight_free_kg']) * CFG['per_kg'], 2);
    $cf   = $method === 'cod' ? round(max(CFG['cod_min'], $cod * CFG['cod_pct']), 2) : 0.0;
    return ['currency' => env('CURRENCY', 'USD'), 'distance_km' => round($km, 2), 'base' => CFG['base_fee'], 'distance_fee' => $dist,
            'weight_fee' => $wt, 'cod_fee' => $cf, 'slot_surcharge' => round($surcharge, 2),
            'total' => round(CFG['base_fee'] + $dist + $wt + $cf + $surcharge, 2)];
}

// ---------- order state machine ----------
const TRANSITIONS = [
    'awaiting_payment' => ['pending', 'cancelled'], 'pending' => ['assigned', 'accepted', 'cancelled'],
    'assigned' => ['accepted', 'pending', 'cancelled'], 'accepted' => ['picked_up', 'pending', 'cancelled'],
    'picked_up' => ['delivered', 'failed'], 'delivered' => [], 'failed' => ['pending'], 'cancelled' => []];

function transition(array $o, string $to, ?string $actor, string $note, array $set = []): void {
    if (!in_array($to, TRANSITIONS[$o['status']], true)) throw new HttpError(409, "Cannot move order from {$o['status']} to $to");
    $cols = ['status = CAST(:to AS order_status)']; $p = ['to' => $to, 'id' => $o['id']];
    foreach ($set as $k => $v) { $cols[] = "$k = :$k"; $p[$k] = $v; }
    q('UPDATE orders SET ' . implode(', ', $cols) . ' WHERE id = :id', $p);
    q('INSERT INTO order_events (order_id, from_status, to_status, actor_user_id, note) VALUES (?, CAST(? AS order_status), CAST(? AS order_status), ?, ?)',
      [$o['id'], $o['status'], $to, $actor, $note]);
}
function order_row(string $id, bool $lock = false): array {
    $r = q('SELECT o.*, t.label AS slot_label, t.end_time AS slot_end FROM orders o JOIN time_slots t ON t.id = o.time_slot_id WHERE o.id = ?' . ($lock ? ' FOR UPDATE OF o' : ''), [$id])->fetch();
    if (!$r) throw new HttpError(404, 'Order not found');
    return $r;
}
function public_order(array $o): array { unset($o['delivery_otp']); return $o; }   // OTP only goes to the customer by SMS
function tx(callable $f): mixed {
    db()->beginTransaction();
    try { $r = $f(); db()->commit(); return $r; } catch (Throwable $e) { if (db()->inTransaction()) db()->rollBack(); throw $e; }
}
