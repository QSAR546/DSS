<?php
declare(strict_types=1);

// ======================= AUTH =======================
function h_login(): never {
    $b = body(); $u = q('SELECT * FROM users WHERE email = ?', [strtolower(trim($b['email'] ?? ''))])->fetch();
    if (!$u || !$u['is_active'] || !password_verify($b['password'] ?? '', $u['password_hash'])) throw new HttpError(401, 'Invalid email or password');
    out(['access_token' => jwt_encode(['sub' => $u['id'], 'role' => $u['role'], 'exp' => time() + 43200]), 'role' => $u['role'], 'name' => $u['full_name']]);
}

// ======================= MERCHANT =======================
function merchant(): array {
    $u = auth('merchant'); $m = q('SELECT * FROM merchants WHERE user_id = ?', [$u['id']])->fetch();
    if (!$m) throw new HttpError(404, 'Merchant profile not found');
    if (!$m['is_approved']) throw new HttpError(403, 'Account awaiting approval');
    return $m + ['phone' => $u['phone'], 'user_id' => $u['id']];
}
function resolve_zone(float $lat, float $lng): array {
    $best = null; $bd = INF;
    foreach (q('SELECT * FROM zones WHERE is_active')->fetchAll() as $z) {
        $d = haversine_km($lat, $lng, (float)$z['center_lat'], (float)$z['center_lng']);
        if ($d <= (float)$z['radius_km'] && $d < $bd) { $best = $z; $bd = $d; }
    }
    return $best ?? throw new HttpError(422, 'Pickup location is outside all service zones');
}
function slot_booked(int $slot, string $day): int {
    return (int)q("SELECT count(*) FROM orders WHERE time_slot_id = ? AND delivery_date = ? AND status <> 'cancelled'", [$slot, $day])->fetchColumn();
}
function prepare_order(array $m, array $b, bool $lock): array {
    $b = validate_order($b);
    $addr = trim($b['pickup_address'] ?? '') ?: $m['default_pickup_address'];
    $lat = $b['pickup_lat'] ?? $m['default_pickup_lat']; $lng = $b['pickup_lng'] ?? $m['default_pickup_lng'];
    if (!$addr || $lat === null || $lng === null) throw new HttpError(422, 'Pickup address required (no saved default)', ['pickup_address' => 'Required']);
    $zone = resolve_zone((float)$lat, (float)$lng);
    $km = haversine_km((float)$lat, (float)$lng, (float)$b['dropoff_lat'], (float)$b['dropoff_lng']) * CFG['road_factor'];
    if ($km > CFG['max_km']) throw new HttpError(422, sprintf('Distance %.1f km exceeds the %d km limit', $km, CFG['max_km']));

    $slot = q('SELECT * FROM time_slots WHERE id = ? AND is_active' . ($lock ? ' FOR UPDATE' : ''), [(int)$b['time_slot_id']])->fetch()
        ?: throw new HttpError(422, 'Unknown time slot', ['time_slot_id' => 'Unknown slot']);
    $today = date('Y-m-d');
    if ($b['delivery_date'] < $today) throw new HttpError(422, 'Delivery date is in the past', ['delivery_date' => 'In the past']);
    if ((strtotime($b['delivery_date']) - strtotime($today)) / 86400 > CFG['max_days_ahead']) throw new HttpError(422, 'Bookings limited to ' . CFG['max_days_ahead'] . ' days ahead', ['delivery_date' => 'Too far ahead']);
    if ($b['delivery_date'] === $today && strtotime("$today {$slot['start_time']}") - time() < CFG['slot_lead_min'] * 60) throw new HttpError(422, 'That slot starts too soon — pick a later one', ['time_slot_id' => 'Too soon']);
    if (slot_booked((int)$slot['id'], $b['delivery_date']) >= (int)$slot['capacity']) throw new HttpError(409, 'Selected time slot is full', ['time_slot_id' => 'Full']);

    $fee = calc_fee($km, (float)($b['weight_kg'] ?? 1), $b['payment_method'], (float)$b['cod_amount'], (float)$slot['surcharge']);
    return [$b, $addr, (float)$lat, (float)$lng, $zone, $slot, $fee];
}

function h_slots(): never {
    $m = merchant(); $day = $_GET['date'] ?? date('Y-m-d'); $o = [];
    foreach (q('SELECT * FROM time_slots WHERE is_active ORDER BY start_time')->fetchAll() as $s) {
        $n = slot_booked((int)$s['id'], $day);
        $o[] = ['id' => (int)$s['id'], 'label' => $s['label'], 'surcharge' => (float)$s['surcharge'], 'capacity' => (int)$s['capacity'], 'booked' => $n, 'available' => $n < $s['capacity']];
    }
    out($o);
}
function h_quote(): never { $m = merchant(); [, , , , $zone, , $fee] = prepare_order($m, body(), false); out(['zone' => $zone['name'], 'fee' => $fee]); }

function h_create_order(): never {
    $m = merchant();
    $res = tx(function () use ($m) {
        [$b, $addr, $lat, $lng, $zone, $slot, $fee] = prepare_order($m, body(), true);   // slot row locked → no overbooking
        $epay = $b['payment_method'] === 'epayment';
        $id = q("SELECT gen_random_uuid()")->fetchColumn();
        $num = sprintf('ORD-%08d', q("SELECT nextval('order_number_seq')")->fetchColumn());
        q("INSERT INTO orders (id, order_number, merchant_id, zone_id, pickup_address, pickup_lat, pickup_lng, pickup_contact_name, pickup_contact_phone,
              customer_name, customer_phone, dropoff_address, dropoff_lat, dropoff_lng, notes, package_description, weight_kg, delivery_date, time_slot_id,
              payment_method, payment_status, cod_amount, distance_km, delivery_fee, fee_breakdown, status, delivery_otp)
           VALUES (:id,:num,:m,:z,:pa,:pla,:plo,:pcn,:pcp,:cn,:cp,:da,:dla,:dlo,:notes,:pd,:w,:dd,:slot,
              CAST(:pm AS payment_method),'pending',:cod,:km,:fee,CAST(:fb AS jsonb),CAST(:st AS order_status),:otp)", [
            'id' => $id, 'num' => $num, 'm' => $m['id'], 'z' => $zone['id'], 'pa' => $addr, 'pla' => $lat, 'plo' => $lng,
            'pcn' => $b['pickup_contact_name'] ?? $m['business_name'], 'pcp' => $b['pickup_contact_phone'] ?? $m['phone'],
            'cn' => trim($b['customer_name']), 'cp' => preg_replace('/[\s-]/', '', $b['customer_phone']), 'da' => trim($b['dropoff_address']),
            'dla' => $b['dropoff_lat'], 'dlo' => $b['dropoff_lng'], 'notes' => $b['notes'] ?? null, 'pd' => $b['package_description'] ?? null,
            'w' => $b['weight_kg'] ?? 1, 'dd' => $b['delivery_date'], 'slot' => $slot['id'], 'pm' => $b['payment_method'], 'cod' => $b['cod_amount'] ?? 0,
            'km' => $fee['distance_km'], 'fee' => $fee['total'], 'fb' => json_encode($fee), 'st' => $epay ? 'awaiting_payment' : 'pending',
            'otp' => str_pad((string)random_int(0, 9999), 4, '0', STR_PAD_LEFT)]);
        q("INSERT INTO order_events (order_id, from_status, to_status, note) VALUES (?, NULL, CAST(? AS order_status), 'created')", [$id, $epay ? 'awaiting_payment' : 'pending']);
        if ($epay) q("INSERT INTO payments (order_id, method, amount, status) VALUES (?, 'epayment', ?, 'pending')", [$id, $fee['total']]);
        return ['order' => public_order(order_row($id)), 'fee' => $fee, 'payment_url' => $epay ? "/pay/$id" : null];   // TODO: gateway checkout session
    });
    out($res, 201);
}

function h_merchant_orders(): never {
    $m = merchant(); $g = $_GET['group'] ?? 'active';
    $sets = ['active' => "('awaiting_payment','pending','assigned','accepted','picked_up')", 'delivered' => "('delivered')", 'closed' => "('failed','cancelled')"];
    $w = 'o.merchant_id = :m'; $p = ['m' => $m['id']];
    if (isset($sets[$g])) $w .= " AND o.status IN {$sets[$g]}";
    if (!empty($_GET['q'])) { $w .= ' AND (o.order_number ILIKE :q OR o.customer_name ILIKE :q OR o.customer_phone ILIKE :q)'; $p['q'] = '%' . $_GET['q'] . '%'; }
    $rows = q("SELECT o.*, t.label AS slot_label, d.current_lat AS driver_lat, d.current_lng AS driver_lng, du.full_name AS driver_name
               FROM orders o JOIN time_slots t ON t.id = o.time_slot_id LEFT JOIN drivers d ON d.id = o.driver_id LEFT JOIN users du ON du.id = d.user_id
               WHERE $w ORDER BY o.created_at DESC LIMIT 100", $p)->fetchAll();
    out(['items' => array_map(function ($r) { if (!in_array($r['status'], ['accepted', 'picked_up'])) $r['driver_lat'] = $r['driver_lng'] = null; return public_order($r); }, $rows)]);
}
function h_merchant_cancel(string $id): never {
    $m = merchant();
    tx(function () use ($m, $id) {
        $o = order_row($id, true); if ($o['merchant_id'] !== $m['id']) throw new HttpError(404, 'Order not found');
        if (in_array($o['status'], ['picked_up', 'delivered', 'failed', 'cancelled'])) throw new HttpError(409, 'Order can no longer be cancelled');
        transition($o, 'cancelled', $m['user_id'], 'cancelled by merchant');
    });
    out(['ok' => true]);
}

// ======================= DRIVER =======================
function driver(): array {
    $u = auth('driver'); $d = q('SELECT * FROM drivers WHERE user_id = ?', [$u['id']])->fetch();
    if (!$d || !$d['is_approved']) throw new HttpError(403, 'Driver not approved');
    return $d + ['full_name' => $u['full_name']];
}
function driver_card(array $o, array $d): array {
    $dist = $d['current_lat'] !== null ? round(haversine_km((float)$d['current_lat'], (float)$d['current_lng'], (float)$o['pickup_lat'], (float)$o['pickup_lng']), 2) : null;
    return ['id' => $o['id'], 'order_number' => $o['order_number'], 'status' => $o['status'],
        'pickup' => ['address' => $o['pickup_address'], 'lat' => (float)$o['pickup_lat'], 'lng' => (float)$o['pickup_lng']],
        'dropoff' => ['address' => $o['dropoff_address'], 'lat' => (float)$o['dropoff_lat'], 'lng' => (float)$o['dropoff_lng']],
        'customer_name' => $o['customer_name'], 'customer_phone' => $o['customer_phone'], 'notes' => $o['notes'], 'slot_label' => $o['slot_label'],
        'payment_method' => $o['payment_method'], 'cod_to_collect' => $o['payment_method'] === 'cod' ? (float)$o['cod_amount'] : 0.0,
        'delivery_fee' => (float)$o['delivery_fee'], 'distance_km' => (float)$o['distance_km'], 'distance_from_driver_km' => $dist,
        'navigate_url' => 'https://www.google.com/maps/dir/?api=1&travelmode=driving&dir_action=navigate&destination=' .
            ($o['status'] === 'picked_up' ? "{$o['dropoff_lat']},{$o['dropoff_lng']}" : "{$o['pickup_lat']},{$o['pickup_lng']}")];
}
function refresh_driver_status(array $d): void {
    $n = q("SELECT count(*) FROM orders WHERE driver_id = ? AND status IN ('assigned','accepted','picked_up')", [$d['id']])->fetchColumn();
    q("UPDATE drivers SET status = CAST(? AS driver_status) WHERE id = ? AND status <> 'offline'", [$n ? 'busy' : 'available', $d['id']]);
}
function h_driver_status(): never {
    $d = driver(); $s = body()['status'] ?? ''; if (!in_array($s, ['available', 'offline'], true)) throw new HttpError(422, 'status must be available|offline');
    q('UPDATE drivers SET status = CAST(? AS driver_status) WHERE id = ?', [$s, $d['id']]); if ($s === 'available') refresh_driver_status($d); out(['status' => $s]);
}
function h_driver_location(): never {
    $d = driver(); $b = body();
    if (!is_numeric($b['lat'] ?? null) || !is_numeric($b['lng'] ?? null) || abs($b['lat']) > 90 || abs($b['lng']) > 180) throw new HttpError(422, 'Invalid coordinates');
    q('UPDATE drivers SET current_lat = ?, current_lng = ?, last_location_at = now() WHERE id = ?', [$b['lat'], $b['lng'], $d['id']]);
    q('INSERT INTO driver_locations (driver_id, lat, lng, heading, speed_kmh) VALUES (?,?,?,?,?)', [$d['id'], $b['lat'], $b['lng'], $b['heading'] ?? null, $b['speed_kmh'] ?? null]);
    http_response_code(204); exit;
}
function h_driver_available(): never {
    $d = driver();
    $rows = q("SELECT o.*, t.label AS slot_label FROM orders o JOIN time_slots t ON t.id = o.time_slot_id
               WHERE o.delivery_date <= CURRENT_DATE AND ((o.status = 'pending' AND o.driver_id IS NULL AND o.zone_id = :z) OR (o.status = 'assigned' AND o.driver_id = :d))
               ORDER BY o.created_at", ['z' => $d['zone_id'], 'd' => $d['id']])->fetchAll();
    $cards = array_map(fn($r) => driver_card($r, $d), $rows);
    if (!empty($_GET['radius_km']) && $d['current_lat'] !== null) $cards = array_values(array_filter($cards, fn($c) => $c['distance_from_driver_km'] !== null && $c['distance_from_driver_km'] <= (float)$_GET['radius_km']));
    usort($cards, fn($a, $b) => [$a['status'] !== 'assigned', $a['distance_from_driver_km'] ?? 1e9] <=> [$b['status'] !== 'assigned', $b['distance_from_driver_km'] ?? 1e9]);
    out($cards);
}
function h_driver_active(): never {
    $d = driver();
    out(array_map(fn($r) => driver_card($r, $d), q("SELECT o.*, t.label AS slot_label FROM orders o JOIN time_slots t ON t.id = o.time_slot_id
        WHERE o.driver_id = ? AND o.status IN ('accepted','picked_up') ORDER BY o.accepted_at", [$d['id']])->fetchAll()));
}
function h_driver_accept(string $id): never {
    $d = driver(); if ($d['status'] === 'offline') throw new HttpError(409, 'Go online before accepting orders');
    tx(function () use ($d, $id) {
        $n = (int)q("SELECT count(*) FROM orders WHERE driver_id = ? AND status IN ('assigned','accepted','picked_up')", [$d['id']])->fetchColumn();
        if ($n >= CFG['max_active_per_driver']) throw new HttpError(409, 'Active order limit reached');
        // atomic claim: only one driver can win
        $s = q("UPDATE orders SET status = 'accepted', driver_id = :d, accepted_at = now()
                WHERE id = :id AND ((status = 'pending' AND driver_id IS NULL AND zone_id = :z) OR (status = 'assigned' AND driver_id = :d))", ['d' => $d['id'], 'id' => $id, 'z' => $d['zone_id']]);
        if ($s->rowCount() !== 1) throw new HttpError(409, 'Order is no longer available');
        q("INSERT INTO order_events (order_id, from_status, to_status, actor_user_id, note) VALUES (?, 'pending', 'accepted', ?, 'accepted by driver')", [$id, $d['user_id']]);
        q("UPDATE drivers SET status = 'busy' WHERE id = ?", [$d['id']]);
    });
    out(['ok' => true]);
}
function my_order(array $d, string $id): array {
    $o = order_row($id, true); if ($o['driver_id'] !== $d['id']) throw new HttpError(404, 'Order not found for this driver'); return $o;
}
function h_driver_release(string $id): never {
    $d = driver();
    tx(function () use ($d, $id) { $o = my_order($d, $id);
        if (!in_array($o['status'], ['assigned', 'accepted'])) throw new HttpError(409, 'Only assigned/accepted orders can be released');
        transition($o, 'pending', $d['user_id'], 'released by driver', ['driver_id' => null, 'assigned_at' => null, 'accepted_at' => null]); refresh_driver_status($d); });
    out(['ok' => true]);
}
function h_driver_pickup(string $id): never {
    $d = driver(); tx(function () use ($d, $id) { transition(my_order($d, $id), 'picked_up', $d['user_id'], 'picked up', ['picked_up_at' => date('c')]); }); out(['ok' => true]);
}
function h_driver_fail(string $id): never {
    $d = driver(); $r = trim(body()['reason'] ?? ''); if (mb_strlen($r) < 3) throw new HttpError(422, 'Give a reason (min 3 chars)', ['reason' => 'Required']);
    tx(function () use ($d, $id, $r) { transition(my_order($d, $id), 'failed', $d['user_id'], $r, ['failure_reason' => $r]); refresh_driver_status($d); }); out(['ok' => true]);
}
function save_upload(array $f, string $folder): string {
    $ok = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if ($f['error'] !== UPLOAD_ERR_OK || $f['size'] > 5 * 1024 * 1024) throw new HttpError(413, 'Upload failed or larger than 5 MB');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);           // trust content, not the client header
    if (!isset($ok[$mime])) throw new HttpError(415, 'Only JPEG/PNG/WebP images');
    $dir = __DIR__ . "/../uploads/$folder"; is_dir($dir) || mkdir($dir, 0755, true);
    $name = bin2hex(random_bytes(12)) . '.' . $ok[$mime]; move_uploaded_file($f['tmp_name'], "$dir/$name");
    return "/uploads/$folder/$name";
}
function h_driver_deliver(string $id): never {
    $d = driver(); $b = $_POST;
    if (!is_numeric($b['lat'] ?? null) || !is_numeric($b['lng'] ?? null)) throw new HttpError(422, 'GPS location is required');
    $res = tx(function () use ($d, $id, $b) {
        $o = my_order($d, $id);
        if ($o['status'] !== 'picked_up') throw new HttpError(409, "Order is {$o['status']}; pick it up first");
        $otp = $b['otp'] ?? ''; $otpOk = $otp !== '' && hash_equals($o['delivery_otp'], $otp);
        if ($otp !== '' && !$otpOk) throw new HttpError(422, 'Incorrect delivery OTP');
        $photo = $_FILES['photo'] ?? null; $sig = $_FILES['signature'] ?? null;
        $hasPhoto = $photo && $photo['error'] !== UPLOAD_ERR_NO_FILE; $hasSig = $sig && $sig['error'] !== UPLOAD_ERR_NO_FILE;
        if (!$hasPhoto && !$hasSig && !$otpOk) throw new HttpError(422, 'Proof required: photo, signature or customer OTP');
        $cod = (float)($b['cod_collected'] ?? 0);
        if ($o['payment_method'] === 'cod' && abs($cod - (float)$o['cod_amount']) > 0.001) throw new HttpError(422, "Collect exactly {$o['cod_amount']} in cash (received $cod)");
        $ins = 'INSERT INTO proofs_of_delivery (order_id, driver_id, type, file_url, otp_value, recipient_name, lat, lng) VALUES (?,?,CAST(? AS pod_type),?,?,?,?,?)';
        $urls = [];
        if ($hasPhoto) { $urls[] = $u = save_upload($photo, "pod/$id"); q($ins, [$id, $d['id'], 'photo', $u, null, $b['recipient_name'] ?? null, $b['lat'], $b['lng']]); }
        if ($hasSig)   { $urls[] = $u = save_upload($sig, "pod/$id");   q($ins, [$id, $d['id'], 'signature', $u, null, $b['recipient_name'] ?? null, $b['lat'], $b['lng']]); }
        if ($otpOk)    q($ins, [$id, $d['id'], 'otp', null, $otp, $b['recipient_name'] ?? null, $b['lat'], $b['lng']]);
        $off = haversine_km((float)$b['lat'], (float)$b['lng'], (float)$o['dropoff_lat'], (float)$o['dropoff_lng']) * 1000;
        $set = ['delivered_at' => date('c')];
        if ($o['payment_method'] === 'cod') {
            q('INSERT INTO cod_collections (order_id, driver_id, merchant_id, amount) VALUES (?,?,?,?)', [$id, $d['id'], $o['merchant_id'], $o['cod_amount']]);
            q("UPDATE orders SET payment_status = 'paid' WHERE id = ?", [$id]);
        }
        transition($o, 'delivered', $d['user_id'], 'delivered' . ($off > 300 ? sprintf(' (⚠ %.0f m from dropoff pin)', $off) : ''), $set);
        refresh_driver_status($d);
        return ['order_id' => $id, 'status' => 'delivered', 'cod_collected' => $o['payment_method'] === 'cod' ? $cod : 0, 'proofs' => $urls];
    });
    out($res);
}

// ======================= ADMIN =======================
function h_admin_live(): never {
    auth('admin');
    out(q("SELECT d.id AS driver_id, u.full_name AS name, d.status, d.zone_id, d.current_lat AS lat, d.current_lng AS lng, d.last_location_at,
                  (SELECT count(*) FROM orders o WHERE o.driver_id = d.id AND o.status IN ('assigned','accepted','picked_up')) AS active_orders
           FROM drivers d JOIN users u ON u.id = d.user_id
           WHERE d.status <> 'offline' AND d.current_lat IS NOT NULL AND d.last_location_at > now() - interval '15 minutes'")->fetchAll());
}
function h_admin_orders(): never {
    auth('admin'); $w = ['1=1']; $p = [];
    if (!empty($_GET['unassigned'])) $w[] = "o.driver_id IS NULL AND o.status = 'pending'";
    if (!empty($_GET['status'])) { $w[] = 'o.status = CAST(:s AS order_status)'; $p['s'] = $_GET['status']; }
    out(['items' => array_map('public_order', q('SELECT o.*, t.label AS slot_label FROM orders o JOIN time_slots t ON t.id = o.time_slot_id WHERE ' . implode(' AND ', $w) . ' ORDER BY o.created_at DESC LIMIT 200', $p)->fetchAll())]);
}
function h_admin_assign(string $id): never {
    $a = auth('admin'); $driverId = body()['driver_id'] ?? '';
    tx(function () use ($a, $id, $driverId) {
        $o = order_row($id, true); $d = q('SELECT * FROM drivers WHERE id = ? AND is_approved', [$driverId])->fetch() ?: throw new HttpError(404, 'Driver not found');
        if ($o['status'] === 'assigned') { transition($o, 'pending', $a['id'], 're-assign', ['driver_id' => null]); $o['status'] = 'pending'; }
        transition($o, 'assigned', $a['id'], 'manual dispatch', ['driver_id' => $d['id'], 'assigned_at' => date('c')]);
    });
    out(['ok' => true]);
}
function h_admin_auto(string $id): never {                   // nearest online driver in the zone, lightest load wins ties
    $a = auth('admin');
    tx(function () use ($a, $id) {
        $o = order_row($id, true); if ($o['status'] !== 'pending') throw new HttpError(409, 'Only pending orders can be auto-dispatched');
        $best = null; $bs = INF;
        foreach (q("SELECT d.*, (SELECT count(*) FROM orders x WHERE x.driver_id = d.id AND x.status IN ('assigned','accepted','picked_up')) AS load
                    FROM drivers d WHERE d.zone_id = ? AND d.is_approved AND d.status <> 'offline' AND d.current_lat IS NOT NULL", [$o['zone_id']])->fetchAll() as $d) {
            if ($d['load'] >= CFG['max_active_per_driver']) continue;
            $s = haversine_km((float)$d['current_lat'], (float)$d['current_lng'], (float)$o['pickup_lat'], (float)$o['pickup_lng']) + $d['load'] * 1.5;
            if ($s < $bs) { $bs = $s; $best = $d; }
        }
        if (!$best) throw new HttpError(404, 'No eligible driver online in this zone');
        transition($o, 'assigned', $a['id'], 'auto-dispatch', ['driver_id' => $best['id'], 'assigned_at' => date('c')]);
    });
    out(['ok' => true]);
}
function h_admin_revenue(): never {
    auth('admin'); $g = $_GET['granularity'] ?? 'day'; if (!in_array($g, ['day', 'week', 'month'], true)) throw new HttpError(422, 'granularity must be day|week|month');
    $s = $_GET['start'] ?? date('Y-m-d', strtotime('-14 days')); $e = $_GET['end'] ?? date('Y-m-d');
    $tz = env('BUSINESS_TZ', 'UTC');
    out(q("SELECT date_trunc('$g', delivered_at AT TIME ZONE :tz) AS period, count(*)::int AS orders, coalesce(sum(delivery_fee),0)::float AS delivery_revenue,
                  coalesce(sum(cod_amount) FILTER (WHERE payment_method = 'cod'),0)::float AS cod_collected,
                  (count(*) FILTER (WHERE payment_method = 'epayment'))::int AS epayment_orders
           FROM orders WHERE status = 'delivered' AND (delivered_at AT TIME ZONE :tz) >= :s AND (delivered_at AT TIME ZONE :tz) < (CAST(:e AS date) + 1)
           GROUP BY 1 ORDER BY 1", ['tz' => $tz, 's' => $s, 'e' => $e])->fetchAll());
}
function h_admin_performance(): never {
    auth('admin'); $s = $_GET['start'] ?? date('Y-m-d', strtotime('-14 days')); $e = $_GET['end'] ?? date('Y-m-d');
    out(q("SELECT d.id AS driver_id, u.full_name AS name, count(*) FILTER (WHERE o.status = 'delivered')::int AS delivered, count(*) FILTER (WHERE o.status = 'failed')::int AS failed,
                  round((avg(extract(epoch FROM o.delivered_at - o.picked_up_at) / 60) FILTER (WHERE o.status = 'delivered'))::numeric, 1)::float AS avg_delivery_minutes,
                  coalesce((SELECT sum(c.amount) FROM cod_collections c WHERE c.driver_id = d.id AND c.status = 'with_driver'),0)::float AS cod_outstanding
           FROM drivers d JOIN users u ON u.id = d.user_id JOIN orders o ON o.driver_id = d.id
           WHERE o.delivery_date BETWEEN :s AND :e AND o.status IN ('delivered','failed') GROUP BY d.id, u.full_name ORDER BY delivered DESC", ['s' => $s, 'e' => $e])->fetchAll());
}
